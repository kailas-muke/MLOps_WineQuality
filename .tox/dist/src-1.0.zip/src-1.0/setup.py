from setuptools import setup, find_packages

setup(
    name="src",
    version="1.0",
    description="It is Wine Quality project",
    author="Kailas Muke",
    packages=find_packages(),
    license="MIT"
)